package com.capg.paymentwallet.dao;

import javax.persistence.EntityManager;

import com.capg.paymentwallet.bean.AccountBean;

public class AccountDAOImpl implements IAccountDao {

	
	
	
	EntityManager em1;
	
	@Override
	public boolean createAccount(AccountBean accountBean) throws Exception {
		try{
			
			
			em1=JPAManager.createEntityManager();
		
			System.out.println("sgfdef");
			em1.getTransaction().begin();
			
			em1.persist(accountBean);
			
			em1.getTransaction().commit();
		
			JPAManager.closeResources(em1);
			
			return true;
		}catch(Exception e){
			return false;
		}
	
	}

	@Override
	public boolean updateAccount(AccountBean accountBean) throws Exception {
		try{
			this.em1=JPAManager.createEntityManager();
			em1.getTransaction().begin();
			
			em1.merge(accountBean);
			
			em1.getTransaction().commit();
			JPAManager.closeResources(em1);
			return true;
		}catch(Exception e){
			return false;
		}
	
	}

	@Override
	public AccountBean findAccount(int accountId) throws Exception {
		try{
			em1=JPAManager.createEntityManager();
			AccountBean accountBean2=em1.find(AccountBean.class,accountId);
			JPAManager.closeResources(em1);
			return accountBean2;
			
		}catch(Exception e){
			return null;
		}
	}

}
