package com.capg.paymentwallet.test;

import static org.junit.Assert.*;

import java.util.Date;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.service.AccountServiceImpl;

public class Test {
AccountServiceImpl service= new AccountServiceImpl();
	@org.junit.Test
    public void testAccount() throws Exception {
           CustomerBean customerBean=new CustomerBean();
           customerBean.setFirstName("kran");
           customerBean.setLastName("gadii");
           customerBean.setAddress("vishakapatnam");
           customerBean.setEmailId("gadisandhya17@gmail.com");
           customerBean.setPhoneNo("9876890876");
           customerBean.setPanNum("CYU897658O");
           AccountBean account=new AccountBean();
           account.setAccountId(101);
           account.setBalance(20000);
           account.setDateOfOpening(new Date());
           account.setInitialDeposit(500);
           account.setCustomerBean(customerBean);
           boolean result=service.createAccount(account);
           assertTrue(result);
           
    }
	@org.junit.Test(expected=CustomerException.class)
    public void testAccountForNegative() throws Exception {
           CustomerBean customerBean=new CustomerBean();
           customerBean.setFirstName("kra");
           customerBean.setLastName("gadii");
           customerBean.setAddress("vishakapatnam");
           customerBean.setEmailId("gadisandhya17@gmail.com");
           customerBean.setPhoneNo("98760876");
           customerBean.setPanNum("CYU897658O");
           AccountBean account=new AccountBean();
           account.setAccountId(101);
           account.setBalance(20000);
           account.setDateOfOpening(new Date());
           account.setInitialDeposit(500);
           account.setCustomerBean(customerBean);
           boolean result=service.createAccount(account);
           assertFalse(result);
           
    }
	
	
	

}
